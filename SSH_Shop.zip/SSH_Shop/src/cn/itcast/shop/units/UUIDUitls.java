package cn.itcast.shop.units;

import java.util.UUID;

public class UUIDUitls {

	/***
	 * 生成激活码
	 * @return
	 */
	public static String getUUID(){
		return UUID.randomUUID().toString().replace("-", "");
	}
	
}
