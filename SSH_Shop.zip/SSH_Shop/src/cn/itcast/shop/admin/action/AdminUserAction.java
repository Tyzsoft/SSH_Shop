package cn.itcast.shop.admin.action;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import cn.itcast.shop.admin.service.AdminUserService;
import cn.itcast.shop.admin.vo.AdminUser;
import cn.itcast.shop.vo.Category;

public class AdminUserAction extends ActionSupport implements ModelDriven<AdminUser>{

	private AdminUser adminUser = new AdminUser();
	@Override
	public AdminUser getModel() {
		// TODO Auto-generated method stub
		return adminUser;
	}
	private AdminUserService adminUserService;
	public void setAdminUserService(AdminUserService adminUserService) {
		this.adminUserService = adminUserService;
	}
	
	public String login(){
		AdminUser admin = adminUserService.login(adminUser);
		if(admin == null){
			this.addActionError("用户名或密码错误！");
			return "loginFail";
		}else{
			ServletActionContext.getRequest().getSession().setAttribute("existAdminUser", admin);
			return "loginSuccess";
		}
		
	}
	
	
}
