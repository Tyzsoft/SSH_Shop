package cn.itcast.shop.admin.action;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import cn.itcast.shop.admin.service.AdminCategorySecondService;
import cn.itcast.shop.service.CategoryService;
import cn.itcast.shop.service.ProductsService;
import cn.itcast.shop.units.PageBean;
import cn.itcast.shop.vo.CategorySecond;
import cn.itcast.shop.vo.Product;

public class AdminProductAction extends ActionSupport implements ModelDriven<Product> {

	private Product product = new Product();
	@Override
	public Product getModel() {
		// TODO Auto-generated method stub
		return product;
	}
	
	private ProductsService productsService;
	public void setProductsService(ProductsService productsService) {
		this.productsService = productsService;
	}
	private int page;
	public void setPage(int page) {
		this.page = page;
	}
	private AdminCategorySecondService adminCategorySecondService;
	public void setAdminCategorySecondService(AdminCategorySecondService adminCategorySecondService) {
		this.adminCategorySecondService = adminCategorySecondService;
	}
	public String findAll(){
		PageBean<Product> pageBean = productsService.findByPage(page);
		ActionContext.getContext().getValueStack().set("pageBean", pageBean);
		return "findAll";
	}
	
	private File upload;
	private String uploadFileName;
	private String uploadContentType;
	public void setUpload(File upload) {
		this.upload = upload;
	}
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}

	
	public String addPage(){
		List<CategorySecond> csList  = adminCategorySecondService.findAll();
		ActionContext.getContext().getValueStack().set("csList", csList);
		
		return "addPageSuccess";
		
	}
	
	public String save() throws IOException{
		product.setPdate(new Date());
		if(upload!=null){
			String path = ServletActionContext.getServletContext()
					.getRealPath("/products");
			File diskFile = new File(path + "//" + uploadFileName);
			
			// 文件上传:
			FileUtils.copyFile(upload, diskFile);
	
			product.setImage("products/" + uploadFileName);
		}
		productsService.save(product);
		return "saveSuccess";
	}
	
	public String delete(){
		product = productsService.findByPid(product.getPid());
		String path = ServletActionContext.getServletContext()
				.getRealPath("/"+product.getImage());
		File file = new File(path);
		file.delete();
		productsService.delete(product);
		return "deleteSuccess";
	}
	
	public String edit(){
		product = productsService.findByPid(product.getPid());
		List<CategorySecond> csList  = adminCategorySecondService.findAll();
		ActionContext.getContext().getValueStack().set("csList", csList);
		return "editSuccess";
	}
	
	public String update() throws IOException{
		
		product.setPdate(new Date());
		if(upload!=null){
			String path = ServletActionContext.getServletContext().getRealPath(
					"/"+product.getImage());
			File file = new File(path);
			file.delete();
			
			String relpath = ServletActionContext.getServletContext()
					.getRealPath("/products");
			File diskFile = new File(relpath + "//" + uploadFileName);
			
			// 文件上传:
			FileUtils.copyFile(upload, diskFile);
			product.setImage("products/"+uploadFileName);
		}
		
		productsService.update(product);
		return "updateSuccess";
	}
	
}
