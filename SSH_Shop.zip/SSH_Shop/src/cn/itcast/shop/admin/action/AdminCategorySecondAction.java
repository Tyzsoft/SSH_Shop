package cn.itcast.shop.admin.action;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import cn.itcast.shop.admin.service.AdminCategorySecondService;
import cn.itcast.shop.service.CategoryService;
import cn.itcast.shop.units.PageBean;
import cn.itcast.shop.vo.Category;
import cn.itcast.shop.vo.CategorySecond;

public class AdminCategorySecondAction extends ActionSupport implements ModelDriven<CategorySecond>{

	private CategorySecond categorySecond = new CategorySecond();
	public CategorySecond getModel() {
		return categorySecond;
	}
	private int page;
	public void setPage(int page) {
		this.page = page;
	}
	
	private AdminCategorySecondService adminCategorySecondService;
	public void setAdminCategorySecondService(AdminCategorySecondService adminCategorySecondService) {
		this.adminCategorySecondService = adminCategorySecondService;
	}
	
	private CategoryService categoryService;
	public void setCategoryService(CategoryService categoryService) {
		this.categoryService = categoryService;
	}
	
	public String findAll(){
		PageBean<CategorySecond> pageBean = adminCategorySecondService.findByPage(page);
		ActionContext.getContext().getValueStack().set("pageBean", pageBean);
		return "findAll";
	}
	
	public String addPage(){
		List<Category> cList = categoryService.findAll();
		ActionContext.getContext().getValueStack().set("cList",cList);
		return "addSuccess";
	}
	public String save(){
		adminCategorySecondService.save(categorySecond);
		return "saveSuccess";
	}
	
	public String delete(){
		categorySecond = adminCategorySecondService.findByCsid(categorySecond.getCsid());
		adminCategorySecondService.delete(categorySecond);
		return "deleteSuccess";
	}
	
	public String edit(){
		categorySecond = adminCategorySecondService.findByCsid(categorySecond.getCsid());
		List<Category> cList = categoryService.findAll();
		ActionContext.getContext().getValueStack().set("cList", cList);
		return "editSuccess";
	}
	
	public String update(){
		adminCategorySecondService.update(categorySecond);
		return "updateSuccess";
	}
	
	
}
