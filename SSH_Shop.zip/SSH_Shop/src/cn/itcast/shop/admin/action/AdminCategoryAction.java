package cn.itcast.shop.admin.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import cn.itcast.shop.service.CategoryService;
import cn.itcast.shop.vo.Category;

public class AdminCategoryAction extends ActionSupport implements ModelDriven<Category>{

	private Category category = new Category();
	@Override
	public Category getModel() {
		// TODO Auto-generated method stub
		return category;
	}
	 
	private CategoryService categoryService;
	public void setCategoryService(CategoryService categoryService) {
		this.categoryService = categoryService;
	}
	public String findAll(){
		List<Category> clist = categoryService.findAll();
		ServletActionContext.getContext().getValueStack().set("cList", clist);
		return "findAll";
	}
	
	public String save(){
		categoryService.save(category);
		return "saveSuccess";
	}
	
	public String delete(){
		category = categoryService.findByCid(category.getCid());
		categoryService.delete(category);
		return "delete";
	}
	
	public String edit(){
		category = categoryService.findByCid(category.getCid());
		return "editSuccess";
	}
	
	public String update(){
		categoryService.update(category);
		return "updateSuccess";
	}
	
}
