package cn.itcast.shop.admin.service;

import java.util.List;

import cn.itcast.shop.admin.dao.AdminCategorySecondDao;
import cn.itcast.shop.units.PageBean;
import cn.itcast.shop.vo.CategorySecond;
import cn.itcast.shop.vo.Order;

public class AdminCategorySecondService {

	private AdminCategorySecondDao adminCategorySecondDao;
	public void setAdminCategorySecondDao(AdminCategorySecondDao adminCategorySecondDao) {
		this.adminCategorySecondDao = adminCategorySecondDao;
	}
	public PageBean<CategorySecond> findByPage(int page) {
		PageBean<CategorySecond> pageBean = new PageBean<CategorySecond>();
		// 设置当前页数:
		pageBean.setPage(page);
		// 设置每页显示记录数:
		// 显示5个
		int limit = 5;
		pageBean.setLimit(limit);
		// 设置总记录数:
		int totalCount = 0;
		totalCount = adminCategorySecondDao.findCount();
		pageBean.setTotalCount(totalCount);
		// 设置总页数
		int totalPage = 0;
		if(totalCount % limit == 0){
			totalPage = totalCount / limit;
		}else{
			totalPage = totalCount / limit + 1;
		}
		pageBean.setTotalPage(totalPage);
		// 设置每页显示数据集合:
		int begin = (page - 1)*limit;
		List<CategorySecond> list = adminCategorySecondDao.findPage(begin,limit);
		pageBean.setList(list);
		return pageBean;
	}
	public void save(CategorySecond categorysecond) {
		adminCategorySecondDao.save(categorysecond);
	}
	public void delete(CategorySecond categorysecond) {
		adminCategorySecondDao.delete(categorysecond);
	}
	public CategorySecond findByCsid(Integer csid) {
		
		return adminCategorySecondDao.findByCsid(csid);
	}
	public void update(CategorySecond categorysecond) {
		adminCategorySecondDao.update(categorysecond);
		
	}
	public List<CategorySecond> findAll() {
		
		return adminCategorySecondDao.findAll();
	}
	
}
