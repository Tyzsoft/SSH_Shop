package cn.itcast.shop.admin.dao;

import java.util.List;

import org.apache.tomcat.jni.Local;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import cn.itcast.shop.units.PageHibernateCallback;
import cn.itcast.shop.vo.CategorySecond;
import cn.itcast.shop.vo.Order;

public class AdminCategorySecondDao extends HibernateDaoSupport{

	public int findCount() {
		String hql="select count(*) from CategorySecond";
		List<Long> list = this.getHibernateTemplate().find(hql);
		if(list!=null){
			return list.get(0).intValue();
		}else{
			return 0; 
		}
	}

	public List<CategorySecond> findPage(int begin, int limit) {
		String hql = "from CategorySecond order by csid desc";
		List<CategorySecond> list = this.getHibernateTemplate().execute(
				new PageHibernateCallback<CategorySecond>(hql, null, begin,
						limit));
		return list;
	}

	public void save(CategorySecond categorysecond) {
		this.getHibernateTemplate().save(categorysecond);
	}

	public void delete(CategorySecond categorysecond) {
		this.getHibernateTemplate().delete(categorysecond);
		
	}

	public CategorySecond findByCsid(Integer csid) {
		
		return this.getHibernateTemplate().get(CategorySecond.class, csid);
	}

	public void update(CategorySecond categorysecond) {
		this.getHibernateTemplate().update(categorysecond);
		
	}

	public List<CategorySecond> findAll() {
		String hql = "from CategorySecond";
		return this.getHibernateTemplate().find(hql);
	}

}
