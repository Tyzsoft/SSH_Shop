package cn.itcast.shop.service;

import cn.itcast.shop.units.MailUitls;
import cn.itcast.shop.units.UUIDUitls;
import cn.itcast.shop.dao.UserDao;
import cn.itcast.shop.vo.User;

public class UserService {

	private UserDao userDao;
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	
	public User findByUsername(String username){
		return userDao.findByUsername(username);
	}

	//注册会员信息
	public void save(User user) {
		
		user.setState(0);
		String code = UUIDUitls.getUUID().toString()+UUIDUitls.getUUID().toString();
		user.setCode(code);
		userDao.save(user);
		
		MailUitls.sendMail(user.getEmail(), code);
		
	}

	public User finBycode(String code) {
		
		return userDao.findBycode(code);
	}

	public void update(User userExist) {
		
		userDao.update(userExist);
		
	}

	public User login(User user) {
		
		return userDao.login(user);
	}

	
	
}
