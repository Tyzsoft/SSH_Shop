package cn.itcast.shop.action;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import cn.itcast.shop.service.CategoryService;
import cn.itcast.shop.service.ProductsService;
import cn.itcast.shop.vo.Category;
import cn.itcast.shop.vo.Product;



public class IndexAction extends ActionSupport{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private CategoryService categoryService;
	public void setCategoryService(CategoryService categoryService) {
		this.categoryService = categoryService;
	}
	
	private ProductsService productsService;
	public void setProductsService(ProductsService productsService) {
		this.productsService = productsService;
	}
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		List<Category> list = categoryService.findAll();
		ActionContext.getContext().getSession().put("cList", list);
		
		List<Product> hList = productsService.findhot();
		ActionContext.getContext().getValueStack().set("hList", hList);
				
		List<Product> nList = productsService.findNew();
		ActionContext.getContext().getValueStack().set("nList",nList);
		return "index";
	}
}
