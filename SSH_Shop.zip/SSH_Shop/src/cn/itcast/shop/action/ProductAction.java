package cn.itcast.shop.action;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import cn.itcast.shop.service.CategoryService;
import cn.itcast.shop.service.ProductsService;
import cn.itcast.shop.units.PageBean;
import cn.itcast.shop.vo.Product;

public class ProductAction extends ActionSupport implements ModelDriven<Product>{
	
	private Product product = new Product();
	
	@Override
	public Product getModel() {
		// TODO Auto-generated method stub
		return product;
	}
	
	private ProductsService productsService;
	public void setProductsService(ProductsService productsService) {
		this.productsService = productsService;
	}
	
	private CategoryService categoryService;
	public void setCategoryService(CategoryService categoryService) {
		this.categoryService = categoryService;
	}
	
	
	private Integer csid;

	public Integer getCsid() {
		return csid;
	}

	public void setCsid(Integer csid) {
		this.csid = csid;
	}
	
	
	private Integer cid;

	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}
	
	// 接收当前页数:
	private int page;

	public void setPage(int page) {
		this.page = page;
	}
	
	public String findByPid(){
		
		product = productsService.findByPid(product.getPid());
		return "findByid";
	}
	// 根据分类的id查询商品:
	public String findByCid(){
		PageBean<Product> pageBean = productsService.findByPageCid(cid, page);
		ActionContext.getContext().getValueStack().set("pageBean", pageBean);
		
		return "findByCid";
	}
	
	public String findByCsid(){
		// 根据二级分类查询商品
		PageBean<Product> pageBean = productsService.findByPageCsid(csid, page);
		// 将PageBean存入到值栈中:
		ActionContext.getContext().getValueStack().set("pageBean", pageBean);
		return "findByCsid";
	}
	
	

}
