package cn.itcast.shop.action;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

import cn.itcast.shop.service.ProductsService;
import cn.itcast.shop.vo.Cart;
import cn.itcast.shop.vo.CartItem;
import cn.itcast.shop.vo.Product;

public class CartAction extends ActionSupport{

	private Integer pid;
	private Integer count;
	
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	
	private ProductsService productsService;
	public void setProductsService(ProductsService productsService) {
		this.productsService = productsService;
	}
	
	public String addCart(){
		
		CartItem cartItem = new CartItem();
		cartItem.setCount(count);
		
		Product product = productsService.findByPid(pid);
		cartItem.setProduct(product);
		Cart cart = getCart();
		cart.addCart(cartItem);
		return "addCart";
	}
	
	public String clearCart(){
		
		Cart cart = getCart();
		cart.clearCart();
		
		return "clearCart";
	}
	
	public String removeCart(){
		
		Cart cart = getCart();
		cart.removeCart(pid);
		return "removeCart";
	}
	
	public String MyCart(){
		return "MyCart";
	}
	
	private Cart getCart() {
		Cart cart =  (Cart) ServletActionContext.getRequest().getSession().getAttribute("cart");
		if(cart==null){
			cart = new Cart();
			ServletActionContext.getRequest().getSession().setAttribute("cart", cart);
		}
		return cart;
	}
	
}
