package cn.itcast.shop.action;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import cn.itcast.shop.service.UserService;
import cn.itcast.shop.vo.User;



public class UserAction extends ActionSupport implements ModelDriven<User>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private UserService userService;
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	private User user = new User();
	@Override
	public User getModel() {
		// TODO Auto-generated method stub
		return user;
	}
	
	private String checkcode;
	
	public void setCheckcode(String checkcode) {
		this.checkcode = checkcode;
	}
	
	
	public String registPage(){
		return "register";
	}
	
	public String findByName() throws IOException{
		
		User userExist = userService.findByUsername(user.getUsername());
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=UTF-8");
		if(userExist!=null){
			response.getWriter().println("<font color='red'>用户名已经存在</font>");
		}else {
			response.getWriter().println("<font color='green'>用户名不存在</font>");
		}
		
		return NONE;
	}

	public String regist(){
		String codeImage = (String) ServletActionContext.getRequest().getSession().getAttribute("checkcode");
		if(!checkcode.equalsIgnoreCase(codeImage)){
			this.addActionError("验证码输入错误!");
			return "checkcodeFail";
		}
		userService.save(user);
		this.addActionMessage("注册成功!请去邮箱激活!");
		return "msg";
	}
	
	public String active(){
		User userExist = userService.finBycode(user.getCode());
		if(userExist!=null){
			userExist.setState(1);
			userExist.setCode(null);
			userService.update(userExist);
			
			this.addActionMessage("账号激活成功，请登录!");
		}else {
			this.addActionMessage("账号激活失败，激活码错误!");
		}
		return "msg";
	}
	
	public String loginPage(){
		return "login";
	}
	
	public String login(){
		
		User userExist = userService.login(user);
		if(userExist==null){
			this.addActionError("登录失败:用户名或密码错误或用户未激活!");
			return "login";
		}else{
			ServletActionContext.getRequest().getSession()
			.setAttribute("existUser", userExist);
			return "loginSuccess";
		}
		
	}
	
	public String quit(){
		ServletActionContext.getRequest().getSession().invalidate();
		return "quit";
	}
}
